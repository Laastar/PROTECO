class Resta
{
	//Metodo que realiza la operacion resta
	public static void inversoSumatorio(double[] arreglo)
	{
		double total = arreglo[0] - arreglo[1];
		System.out.println("La resta es: " + total);
	}
}
