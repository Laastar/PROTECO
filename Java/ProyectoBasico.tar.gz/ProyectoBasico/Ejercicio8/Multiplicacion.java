class Multiplicacion
{
	//Metodo que realiza la operacion multiplicacion
	public static void multiplicar(double[] arreglo)
	{
		double total = arreglo[0] * arreglo[1];
		System.out.println("La multiplicacion es: " + total);
	}
}
