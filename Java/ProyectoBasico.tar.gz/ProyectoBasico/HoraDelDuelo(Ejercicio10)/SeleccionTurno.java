import java.util.Scanner;
import java.lang.Boolean;
class SeleccionTurno
{
	//Con este metodo se calcula a quien le toca tirar algun ataque y en que momento
	public static boolean turno(int seleccion)
	{
		if(seleccion  == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
