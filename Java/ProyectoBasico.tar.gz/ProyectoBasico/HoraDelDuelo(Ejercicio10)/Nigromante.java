class Nigromante extends Magicos
{
	//Copnstructor del Nigromante que contiene diferentes stats
	Nigromante(String nombre)
	{
		super(nombre);
		super.setDamage(40);
		super.setDefensa(10);
	}
}
