//Interfaz que guarda la declaracion de los metodos a usar
interface Ninjutsu
{
	void rasenShuriken();
	void odamaRasengan();
	void rasengan();
}