class Español
{
	String palabra;

	Español(String palabra)
	{
		this.palabra = palabra;
	}

	public String getPalabra()
	{
		return palabra;
	}
}