class Ingles
{
	String palabra;

	Ingles(String palabra)
	{
		this.palabra = palabra;
	}

	public String getPalabra()
	{
		return palabra;
	}
}