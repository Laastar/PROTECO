class Suma
{
	//Se realiza la operacion suma
	public static void sumatoria(double[] arreglo)
	{
		double total = arreglo[0] + arreglo[1];
		System.out.println("La suma es: " + total);
	}
}
