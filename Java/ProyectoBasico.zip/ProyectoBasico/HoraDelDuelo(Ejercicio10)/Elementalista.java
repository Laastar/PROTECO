class Elementalista extends Magicos
{
	//Copnstructor del Elementalista que contiene diferentes stats
	Elementalista(String nombre)
	{
		super(nombre);
		super.setDamage(40);
		super.setRegenHealth(15);
	}
}
